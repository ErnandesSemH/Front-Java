package com.example.gunlibrary.guns;

import com.example.gunlibrary.guns.models.*;
import org.junit.jupiter.api.Test;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class GunPolymorphismTest {

    private List<Gun> allGuns() {
        return List.of(
            new M1911(), new ColtPython(), new AK47(),
            new Remington700(), new Remington870()
        );
    }

    @Test
    void eachGunHasItsOwnTriggerAndSound() {
        Set<String> triggers = new HashSet<>();
        Set<String> sounds = new HashSet<>();

        for (Gun gun : allGuns()) {
            triggers.add(gun.getTriggerType());
            sounds.add(gun.getSound());
        }

        assertEquals(5, triggers.size());
        assertEquals(5, sounds.size());
    }

    @Test
    void cannotShootWithSafetyOn() {
        for (Gun gun : allGuns()) {
            assertFalse(gun.shoot().success(), gun.getName());
            assertEquals(gun.getCapacity(), gun.getAmmoOnMag(), gun.getName());
        }
    }

    @Test
    void everyGunCanBeEmptiedAndReloaded() {
        for (Gun gun : allGuns()) {
            gun.toggleSafety();
            while (gun.shoot().success()) { /* esvazia */ }
            assertTrue(gun.isEmpty(), gun.getName());

            assertTrue(gun.reload().success(), gun.getName());
            assertEquals(gun.getCapacity(), gun.getAmmoOnMag(), gun.getName());
        }
    }

    @Test
    void revolverAndShotgunReloadWithoutSpareMagazines() {
        Gun python = new ColtPython();
        Gun shotgun = new Remington870();

        assertFalse(python.usesMagazine());
        assertFalse(shotgun.usesMagazine());
        assertTrue(new M1911().usesMagazine());
    }

    @Test
    void magazineGunStopsReloadingWhenSparesRunOut() {
        Gun gun = new M1911();
        gun.toggleSafety();

        for (int i = 0; i < 3; i++) {
            while (gun.shoot().success()) { /* esvazia */ }
            assertTrue(gun.reload().success());
        }

        while (gun.shoot().success()) { /* esvazia */ }
        assertFalse(gun.reload().success());
        assertEquals(0, gun.getAmmoOnMag());
    }

    @Test
    void precisionRifleExposesScopeInfo() {
        assertNotNull(new Remington700().getExtraInfo());
        assertNull(new AK47().getExtraInfo());
    }
}
