package com.example.gunlibrary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GunlibraryApplicationTests {

	@Test
	void contextLoads() {
	}

}
