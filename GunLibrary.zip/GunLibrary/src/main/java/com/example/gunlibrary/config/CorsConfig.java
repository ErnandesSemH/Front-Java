package com.example.gunlibrary.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * CORS global da API. O front roda no Live Server (porta 5500), que é outra
 * origem em relação ao Spring (porta 8080). O Live Server abre tanto em
 * "localhost" quanto em "127.0.0.1", então as duas são liberadas.
 */
@Configuration
public class CorsConfig implements WebMvcConfigurer {

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/api/**")
            .allowedOrigins(
                "http://localhost:5500",
                "http://127.0.0.1:5500",
                "http://localhost:5173"
            )
            .allowedMethods("GET", "POST", "OPTIONS");
    }
}
