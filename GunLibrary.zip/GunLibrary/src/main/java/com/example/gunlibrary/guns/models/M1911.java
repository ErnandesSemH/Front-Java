package com.example.gunlibrary.guns.models;

import com.example.gunlibrary.guns.Pistol;
import com.example.gunlibrary.guns.FireMode;

public class M1911 extends Pistol {

    public M1911() {
        super(
            "M1911",
            "Colt",
            1911,
            1.1,
            ".45 ACP",
            7,
            FireMode.SEMI_AUTOMATIC,
            50.0,
            0,
            3
        );
    }
}
