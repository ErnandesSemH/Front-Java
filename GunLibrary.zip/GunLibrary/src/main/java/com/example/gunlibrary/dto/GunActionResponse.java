package com.example.gunlibrary.dto;

import com.example.gunlibrary.guns.ActionResult;
import com.example.gunlibrary.guns.Gun;

/** Resposta das ações (atirar, recarregar, trava, manutenção). */
public record GunActionResponse(
    boolean success,
    String message,
    GunResponse gun
) {
    public static GunActionResponse of(int id, Gun gun, ActionResult result) {
        return new GunActionResponse(
            result.success(),
            result.message(),
            GunResponse.from(id, gun)
        );
    }
}
