package com.example.gunlibrary.guns.models;

import com.example.gunlibrary.guns.Shotgun;
import com.example.gunlibrary.guns.FireMode;

public class Remington870 extends Shotgun {

    public Remington870() {
        super(
            "Remington 870",
            "Remington Arms",
            1950,
            3.2,
            "12 Gauge",
            5,
            FireMode.MANUAL,
            40.0,
            0
        );
    }

    @Override
    public String getTriggerType() {
        return "Ação simples, com trava de segurança cruzada atrás do gatilho";
    }

    @Override
    public String getSound() {
        return "BOOM! grave do calibre 12, seguido do CLACK-CLACK da bomba";
    }

    @Override
    public String getMechanism() {
        return "Ação de bombeamento (pump-action) com tubo magazine sob o cano";
    }
}
