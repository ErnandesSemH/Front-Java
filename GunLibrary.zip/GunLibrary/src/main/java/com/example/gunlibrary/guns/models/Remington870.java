package com.example.gunlibrary.guns.models;

import com.example.gunlibrary.guns.Shotgun;
import com.example.gunlibrary.guns.FireMode;

public class Remington870 extends Shotgun {

    public Remington870() {
        super(
            "Remington 870",
            "Remington Arms",
            1950,
            3.2,
            "12 Gauge",
            5,
            FireMode.MANUAL,
            40.0,
            0,
            0
        );
    }
}
