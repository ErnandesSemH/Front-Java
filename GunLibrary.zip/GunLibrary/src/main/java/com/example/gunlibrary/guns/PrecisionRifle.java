
package com.example.gunlibrary.guns;

public abstract class PrecisionRifle extends Rifle {

    private double scopeMagnification;

    public PrecisionRifle(
            String name,
            String producer,
            int year,
            double weight,
            String caliber,
            int capacity,
            double effectiveRange,
            int fireRate,
            int magazineCount,
            double scopeMagnification
    ) {
        super(
                name, producer, year, weight, caliber,
                capacity, FireMode.MANUAL,
                effectiveRange, fireRate, magazineCount
        );

        if (!Double.isFinite(scopeMagnification)
                || scopeMagnification < 1) {
            throw new IllegalArgumentException(
                    "Invalid scope magnification."
            );
        }

        this.scopeMagnification = scopeMagnification;
    }

    public double getScopeMagnification() {
        return scopeMagnification;
    }

    @Override
    public void showData() {
        super.showData();
        System.out.println(
                "Scope magnification: " + scopeMagnification + "x"
        );
    }
}
