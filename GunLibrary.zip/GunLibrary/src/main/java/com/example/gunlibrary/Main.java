package com.example.gunlibrary;


import com.example.gunlibrary.guns.Gun;

import com.example.gunlibrary.guns.models.M1911;
import com.example.gunlibrary.guns.models.ColtPython;
import com.example.gunlibrary.guns.models.AK47;
import com.example.gunlibrary.guns.models.Remington700;
import com.example.gunlibrary.guns.models.Remington870;

public class Main {

    public static void main(String[] args) {

        Gun[] guns = {
            new M1911(),
            new ColtPython(),
            new AK47(),
            new Remington700(),
            new Remington870()
        };

        for (Gun gun : guns) {

            gun.showData();

            gun.toggleSafety();
            gun.shoot();

            gun.inspect();

            System.out.println("\n--------------------\n");
        }
    }
}
