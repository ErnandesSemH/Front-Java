package com.example.gunlibrary.dto;

import com.example.gunlibrary.guns.Gun;

public record GunResponse(
    int id,
    String name,
    String producer,
    int year,
    double weight,
    String caliber,
    String type,
    String fireMode,
    double effectiveRange,
    int capacity,
    int ammo,
    boolean safetyOn,
    double condition,
    int totalShots,
    boolean usesMagazine,
    int spareMagazines,
    // Comportamento polimórfico: cada subclasse responde de um jeito
    String triggerType,
    String sound,
    String mechanism,
    String extraInfo
) {
    public static GunResponse from(int id, Gun gun) {
        return new GunResponse(
            id,
            gun.getName(),
            gun.getProducer(),
            gun.getYear(),
            gun.getWeight(),
            gun.getCaliber(),
            gun.getType().name(),
            gun.getFireMode().name(),
            gun.getEffectiveRange(),
            gun.getCapacity(),
            gun.getAmmoOnMag(),
            gun.isSafetyOn(),
            gun.getCondition(),
            gun.getTotalShots(),
            gun.usesMagazine(),
            gun.getMagazineCount(),
            gun.getTriggerType(),
            gun.getSound(),
            gun.getMechanism(),
            gun.getExtraInfo()
        );
    }
}
