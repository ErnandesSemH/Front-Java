
package com.example.gunlibrary.dto;

import com.example.gunlibrary.guns.Gun;

public record GunResponse(
    int id,
    String name,
    String producer,
    int year,
    double weight,
    String caliber,
    String type,
    int capacity,
    int ammo,
    boolean safetyOn,
    double condition,
    int totalShots,
    int spareMagazines,
    String fireMode
) {
    public static GunResponse from(int id, Gun gun) {
        return new GunResponse(
            id,
            gun.getName(),
            gun.getProducer(),
            gun.getYear(),
            gun.getWeight(),
            gun.getCaliber(),
            gun.getType().name(),
            gun.getCapacity(),
            gun.getAmmoOnMag(),
            gun.isSafetyOn(),
            gun.getCondition(),
            gun.getTotalShots(),
            gun.getMagazineCount(),
            gun.getFireMode().name()
        );
    }
}
