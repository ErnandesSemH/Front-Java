package com.example.gunlibrary;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GunlibraryApplication {

	public static void main(String[] args) {
		SpringApplication.run(GunlibraryApplication.class, args);
	}

}
