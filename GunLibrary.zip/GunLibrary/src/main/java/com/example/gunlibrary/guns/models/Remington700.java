package com.example.gunlibrary.guns.models;

import com.example.gunlibrary.guns.PrecisionRifle;

public class Remington700 extends PrecisionRifle {

    public Remington700() {
        super(
            "Remington 700",
            "Remington Arms",
            1962,
            3.6,
            ".308 Winchester",
            5,
            800.0,
            0,
            3,
            10.0
        );
    }

    @Override
    public String getTriggerType() {
        return "Ação simples, ajustável e de quebra limpa, pensada para precisão";
    }

    @Override
    public String getSound() {
        return "CRACK! agudo e seco do .308 Winchester";
    }

    @Override
    public String getMechanism() {
        return "Ferrolho rotativo manual: o atirador cicla a alavanca a cada tiro";
    }
}
