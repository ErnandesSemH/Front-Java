
package com.example.gunlibrary.guns;

public enum GunType {
    PISTOL,
    REVOLVER,
    RIFLE,
    SHOTGUN,
    SUBMACHINE_GUN,
    MACHINE_GUN
}
