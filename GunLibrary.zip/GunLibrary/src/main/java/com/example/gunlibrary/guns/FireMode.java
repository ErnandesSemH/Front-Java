package com.example.gunlibrary.guns;

public enum FireMode {
    SINGLE_ACTION,
    DOUBLE_ACTION,
    SEMI_AUTOMATIC,
    BURST,
    AUTOMATIC,
    MANUAL
}
