package com.example.gunlibrary.guns;

public enum FireMode {
    SINGLE_ACTION,
    SEMI_AUTOMATIC,
    BURST,
    AUTOMATIC,
    MANUAL
}