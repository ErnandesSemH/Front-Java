package com.example.gunlibrary.guns;

/**
 * Revólver: não usa carregador removível. A recarga enche o tambor
 * (pelas janelas de carga / speedloader), por isso sobrescreve reload().
 */
public abstract class Revolver extends Gun {

    public Revolver(
            String name,
            String producer,
            int year,
            double weight,
            String caliber,
            int capacity,
            FireMode fireMode,
            double effectiveRange,
            int fireRate
    ) {
        super(
                name, producer, year, weight, caliber,
                capacity, GunType.REVOLVER, fireMode,
                effectiveRange, fireRate, 0
        );
    }

    @Override
    public ActionResult reload() {
        return refillChambers("no tambor (speedloader)");
    }

    @Override
    public boolean usesMagazine() {
        return false;
    }
}
