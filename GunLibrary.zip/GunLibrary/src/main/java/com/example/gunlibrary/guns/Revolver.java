
package com.example.gunlibrary.guns;

public abstract class Revolver extends Gun {

    public Revolver(
            String name,
            String producer,
            int year,
            double weight,
            String caliber,
            int capacity,
            double effectiveRange,
            int fireRate
    ) {
        super(
                name, producer, year, weight, caliber,
                capacity, GunType.REVOLVER,
                FireMode.SINGLE_ACTION,
                effectiveRange, fireRate, 0
        );
    }

    @Override
    public void shoot() {
        if (consumeAmmo()) {
            System.out.println(getName() + " fired!");
        }
    }
}
