
package com.example.gunlibrary.service;

import com.example.gunlibrary.guns.Gun;
import com.example.gunlibrary.guns.models.*;
import com.example.gunlibrary.dto.GunResponse;

import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;

import java.util.List;
import java.util.stream.IntStream;

@Service
public class GunService {

    private final List<Gun> guns = List.of(
        new M1911(),
        new ColtPython(),
        new AK47(),
        new Remington700(),
        new Remington870()
    );

    public List<GunResponse> findAll() {
        return IntStream.range(0, guns.size())
            .mapToObj(i -> GunResponse.from(i + 1, guns.get(i)))
            .toList();
    }

    public synchronized Gun findById(int id) {
        if (id < 1 || id > guns.size()) {
            throw new ResponseStatusException(
                HttpStatus.NOT_FOUND,
                "Gun not found"
            );
        }

        return guns.get(id - 1);
    }

    public synchronized GunResponse shoot(int id) {
        Gun gun = findById(id);
        gun.shoot();
        return GunResponse.from(id, gun);
    }

    public synchronized GunResponse reload(int id) {
        Gun gun = findById(id);
        gun.reload();
        return GunResponse.from(id, gun);
    }

    public synchronized GunResponse toggleSafety(int id) {
        Gun gun = findById(id);
        gun.toggleSafety();
        return GunResponse.from(id, gun);
    }

    public synchronized GunResponse maintain(int id) {
        Gun gun = findById(id);
        gun.maintain();
        return GunResponse.from(id, gun);
    }
}
