package com.example.gunlibrary.service;

import com.example.gunlibrary.dto.GunActionResponse;
import com.example.gunlibrary.dto.GunResponse;
import com.example.gunlibrary.guns.Gun;
import com.example.gunlibrary.guns.models.*;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.stream.IntStream;

@Service
public class GunService {

    // O estado das armas é mutável (munição, trava...), então todo acesso
    // passa por métodos synchronized.
    private final List<Gun> guns = List.of(
        new M1911(),
        new ColtPython(),
        new AK47(),
        new Remington700(),
        new Remington870()
    );

    public synchronized List<GunResponse> findAll() {
        return IntStream.range(0, guns.size())
            .mapToObj(i -> GunResponse.from(i + 1, guns.get(i)))
            .toList();
    }

    public synchronized GunResponse findResponseById(int id) {
        return GunResponse.from(id, findById(id));
    }

    public synchronized GunActionResponse shoot(int id) {
        Gun gun = findById(id);
        return GunActionResponse.of(id, gun, gun.shoot());
    }

    public synchronized GunActionResponse reload(int id) {
        Gun gun = findById(id);
        return GunActionResponse.of(id, gun, gun.reload());
    }

    public synchronized GunActionResponse toggleSafety(int id) {
        Gun gun = findById(id);
        return GunActionResponse.of(id, gun, gun.toggleSafety());
    }

    public synchronized GunActionResponse maintain(int id) {
        Gun gun = findById(id);
        return GunActionResponse.of(id, gun, gun.maintain());
    }

    private Gun findById(int id) {
        if (id < 1 || id > guns.size()) {
            throw new ResponseStatusException(
                HttpStatus.NOT_FOUND,
                "Gun not found"
            );
        }

        return guns.get(id - 1);
    }
}
