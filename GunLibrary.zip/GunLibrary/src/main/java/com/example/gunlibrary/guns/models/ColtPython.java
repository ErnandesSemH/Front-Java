package com.example.gunlibrary.guns.models;

import com.example.gunlibrary.guns.FireMode;
import com.example.gunlibrary.guns.Revolver;

public class ColtPython extends Revolver {

    public ColtPython() {
        super(
            "Colt Python",
            "Colt",
            1955,
            1.2,
            ".357 Magnum",
            6,
            FireMode.DOUBLE_ACTION,
            50.0,
            0
        );
    }

    @Override
    public String getTriggerType() {
        return "Dupla ação: puxar o gatilho gira o tambor e arma o cão (também pode ser armado manualmente)";
    }

    @Override
    public String getSound() {
        return "BOOM! estrondoso do .357 Magnum";
    }

    @Override
    public String getMechanism() {
        return "Tambor oscilante de 6 câmaras que gira a cada acionamento";
    }
}
