package com.example.gunlibrary.guns.models;

import com.example.gunlibrary.guns.Revolver;

public class ColtPython extends Revolver {

    public ColtPython() {
        super(
            "Colt Python",
            "Colt",
            1955,
            1.2,
            ".357 Magnum",
            6,
            50.0,
            0
        );
    }
}
