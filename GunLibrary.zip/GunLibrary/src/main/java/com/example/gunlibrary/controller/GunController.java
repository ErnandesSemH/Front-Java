
package com.example.gunlibrary.controller;

import com.example.gunlibrary.service.GunService;
import com.example.gunlibrary.dto.GunResponse;

import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/guns")
@CrossOrigin(origins = "http://localhost:5173")
public class GunController {

    private final GunService service;

    public GunController(GunService service) {
        this.service = service;
    }

    @GetMapping
    public List<GunResponse> getAll() {
        return service.findAll();
    }

    @GetMapping("/{id}")
    public GunResponse getById(@PathVariable int id) {
        return GunResponse.from(id, service.findById(id));
    }

    @PostMapping("/{id}/shoot")
    public GunResponse shoot(@PathVariable int id) {
        return service.shoot(id);
    }

    @PostMapping("/{id}/reload")
    public GunResponse reload(@PathVariable int id) {
        return service.reload(id);
    }

    @PostMapping("/{id}/safety")
    public GunResponse toggleSafety(@PathVariable int id) {
        return service.toggleSafety(id);
    }

    @PostMapping("/{id}/maintain")
    public GunResponse maintain(@PathVariable int id) {
        return service.maintain(id);
    }
}
