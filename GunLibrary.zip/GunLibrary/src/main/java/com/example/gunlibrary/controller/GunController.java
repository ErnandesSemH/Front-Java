package com.example.gunlibrary.controller;

import com.example.gunlibrary.dto.GunActionResponse;
import com.example.gunlibrary.dto.GunResponse;
import com.example.gunlibrary.service.GunService;

import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/guns")
public class GunController {

    private final GunService service;

    public GunController(GunService service) {
        this.service = service;
    }

    @GetMapping
    public List<GunResponse> getAll() {
        return service.findAll();
    }

    @GetMapping("/{id}")
    public GunResponse getById(@PathVariable int id) {
        return service.findResponseById(id);
    }

    @PostMapping("/{id}/shoot")
    public GunActionResponse shoot(@PathVariable int id) {
        return service.shoot(id);
    }

    @PostMapping("/{id}/reload")
    public GunActionResponse reload(@PathVariable int id) {
        return service.reload(id);
    }

    @PostMapping("/{id}/safety")
    public GunActionResponse toggleSafety(@PathVariable int id) {
        return service.toggleSafety(id);
    }

    @PostMapping("/{id}/maintain")
    public GunActionResponse maintain(@PathVariable int id) {
        return service.maintain(id);
    }
}
