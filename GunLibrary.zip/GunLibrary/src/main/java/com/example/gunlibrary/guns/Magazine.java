package com.example.gunlibrary.guns;

public class Magazine {
    private final int capacity;
    private int ammunition;

    public Magazine(int capacity) {
        if (capacity <= 0) {
            throw new IllegalArgumentException("Invalid capacity");
        }

        this.capacity = capacity;
        this.ammunition = capacity;
    }

    public int getAmmunition() {
        return ammunition;
    }
}