package com.example.gunlibrary.guns;

/**
 * Espingarda de tubo: os cartuchos são inseridos um a um, então
 * não há carregador reserva. Sobrescreve reload().
 */
public abstract class Shotgun extends Gun {

    public Shotgun(
            String name,
            String producer,
            int year,
            double weight,
            String caliber,
            int capacity,
            FireMode fireMode,
            double effectiveRange,
            int fireRate
    ) {
        super(
                name, producer, year, weight, caliber,
                capacity, GunType.SHOTGUN, fireMode,
                effectiveRange, fireRate, 0
        );
    }

    @Override
    public ActionResult reload() {
        return refillChambers("cartucho por cartucho no tubo");
    }

    @Override
    public boolean usesMagazine() {
        return false;
    }
}
