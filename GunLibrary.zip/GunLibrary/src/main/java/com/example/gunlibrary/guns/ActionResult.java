package com.example.gunlibrary.guns;

/**
 * Resultado de uma ação executada sobre uma arma (atirar, recarregar, etc.).
 * Substitui os System.out.println que antes "escondiam" a mensagem no terminal:
 * agora o front recebe o que aconteceu.
 */
public record ActionResult(boolean success, String message) {

    public static ActionResult ok(String message) {
        return new ActionResult(true, message);
    }

    public static ActionResult fail(String message) {
        return new ActionResult(false, message);
    }
}
