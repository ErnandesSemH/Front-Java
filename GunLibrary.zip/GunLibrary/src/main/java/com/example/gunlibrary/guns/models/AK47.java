
package com.example.gunlibrary.guns.models;

import com.example.gunlibrary.guns.Rifle;
import com.example.gunlibrary.guns.FireMode;

public class AK47 extends Rifle {

    public AK47() {
        super(
            "AK-47",
            "Kalashnikov",
            1947,
            4.3,
            "7.62x39mm",
            30,
            FireMode.AUTOMATIC,
            350.0,
            600,
            3
        );
    }
}
