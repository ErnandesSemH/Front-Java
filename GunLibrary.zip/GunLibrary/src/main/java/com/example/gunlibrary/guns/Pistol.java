
package com.example.gunlibrary.guns;

public abstract class Pistol extends Gun {

    public Pistol(
            String name,
            String producer,
            int year,
            double weight,
            String caliber,
            int capacity,
            FireMode fireMode,
            double effectiveRange,
            int fireRate,
            int magazineCount
    ) {
        super(
                name, producer, year, weight, caliber,
                capacity, GunType.PISTOL, fireMode,
                effectiveRange, fireRate, magazineCount
        );
    }

    @Override
    public void shoot() {
        if (consumeAmmo()) {
            System.out.println(getName() + " fired!");
        }
    }
}
