
package com.example.gunlibrary.guns;

import java.time.Year;


public abstract class Gun {

    // =========================
    // ATTRIBUTES
    // =========================

    private String name;
    private String producer;
    private int year;
    private double weight;
    private String caliber;

    private GunType type;
    private FireMode fireMode;

    private double effectiveRange;
    private int fireRate;

    private int totalShots;
    private boolean safetyOn;
    private double condition;

    private final int capacity;
    private int ammoOnMag;
    private int magazineCount;

    // =========================
    // CONSTRUCTORS
    // =========================

    public Gun(
            String name,
            String producer,
            int year,
            double weight,
            String caliber,
            int capacity
    ) {
        this(
                name, producer, year, weight, caliber, capacity,
                GunType.RIFLE, FireMode.SEMI_AUTOMATIC,
                0, 0, 0
        );
    }

    public Gun(
            String name,
            String producer,
            int year,
            double weight,
            String caliber,
            int capacity,
            GunType type,
            FireMode fireMode,
            double effectiveRange,
            int fireRate,
            int magazineCount
    ) {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Invalid gun name.");
        }

        if (producer == null || producer.isBlank()) {
            throw new IllegalArgumentException("Invalid producer.");
        }

        if (year < 1800 || year > Year.now().getValue()) {
            throw new IllegalArgumentException("Invalid manufacturing year.");
        }

        if (!Double.isFinite(weight) || weight <= 0) {
            throw new IllegalArgumentException("Invalid weight.");
        }

        if (caliber == null || caliber.isBlank()) {
            throw new IllegalArgumentException("Invalid caliber.");
        }

        if (capacity <= 0) {
            throw new IllegalArgumentException("Capacity must be positive.");
        }

        if (type == null || fireMode == null) {
            throw new IllegalArgumentException("Invalid gun type or fire mode.");
        }

        if (!Double.isFinite(effectiveRange) || effectiveRange < 0) {
            throw new IllegalArgumentException("Invalid effective range.");
        }

        if (fireRate < 0 || magazineCount < 0) {
            throw new IllegalArgumentException("Invalid fire rate or magazine count.");
        }

        this.name = name;
        this.producer = producer;
        this.year = year;
        this.weight = weight;
        this.caliber = caliber;
        this.capacity = capacity;
        this.ammoOnMag = capacity;

        this.type = type;
        this.fireMode = fireMode;
        this.effectiveRange = effectiveRange;
        this.fireRate = fireRate;

        this.totalShots = 0;
        this.safetyOn = true;
        this.condition = 100.0;
        this.magazineCount = magazineCount;
    }

    // =========================
    // ABSTRACT METHODS
    // =========================

    public abstract void shoot();

    // =========================
    // AMMUNITION
    // =========================

    protected boolean consumeAmmo() {
        if (safetyOn) {
            System.out.println("Safety is ON!");
            return false;
        }

        if (ammoOnMag <= 0) {
            System.out.println("No ammo!");
            return false;
        }

        ammoOnMag--;
        totalShots++;

        condition = Math.max(0, condition - 0.1);

        return true;
    }

    public void reload() {
        reload(capacity - ammoOnMag);
    }

    public void reload(int amount) {
        if (amount <= 0) {
            System.out.println("Invalid reload amount.");
            return;
        }

        if (ammoOnMag == capacity) {
            System.out.println("Magazine is already full.");
            return;
        }

        if (magazineCount <= 0) {
            System.out.println("No spare magazines!");
            return;
        }

        int availableSpace = capacity - ammoOnMag;
        int ammoToAdd = Math.min(amount, availableSpace);

        ammoOnMag += ammoToAdd;
        magazineCount--;

        System.out.println(
            name + " reloaded +" + ammoToAdd +
            ": " + ammoOnMag + "/" + capacity
        );
    }

    public boolean isEmpty() {
        return ammoOnMag == 0;
    }

    public double getAmmoPercentage() {
        return (ammoOnMag * 100.0) / capacity;
    }

    // =========================
    // SAFETY
    // =========================

    public void toggleSafety() {
        safetyOn = !safetyOn;

        System.out.println(
                safetyOn ? "Safety ON" : "Safety OFF"
        );
    }

    // =========================
    // CONDITION
    // =========================

    public void inspect() {
        System.out.println("\n===== GUN INSPECTION =====");
        System.out.println("Name: " + name);
        System.out.println("Condition: " + condition + "%");
        System.out.println("Safety: " + (safetyOn ? "ON" : "OFF"));
        System.out.println("Ammo: " + ammoOnMag + "/" + capacity);
        System.out.println("Spare magazines: " + magazineCount);
        System.out.println("Total shots: " + totalShots);
        System.out.println("==========================");
    }

    public void maintain() {
        condition = 100.0;
        System.out.println(name + " maintenance completed.");
    }

    // =========================
    // COMPARISON
    // =========================

    public void compareWeight(Gun other) {
        if (other == null) {
            throw new IllegalArgumentException("Cannot compare with null.");
        }

        if (this.weight > other.weight) {
            System.out.println(
                    this.name + " is heavier than " + other.name
            );
        } else if (this.weight < other.weight) {
            System.out.println(
                    this.name + " is lighter than " + other.name
            );
        } else {
            System.out.println("Both guns have the same weight.");
        }
    }

    // =========================
    // INFORMATION
    // =========================

    public void showData() {
        System.out.println("\n===== GUN DATA =====");
        System.out.println("Name: " + name);
        System.out.println("Producer: " + producer);
        System.out.println("Year: " + year);
        System.out.println("Weight: " + weight + " kg");
        System.out.println("Caliber: " + caliber);
        System.out.println("Type: " + type);
        System.out.println("Fire mode: " + fireMode);
        System.out.println("Effective range: " + effectiveRange + " m");
        System.out.println("Fire rate: " + fireRate + " RPM");
        System.out.println("Capacity: " + capacity);
        System.out.println("Current ammo: " + ammoOnMag);
        System.out.println("Spare magazines: " + magazineCount);
        System.out.println("Condition: " + condition + "%");
        System.out.println("Total shots: " + totalShots);
        System.out.println("====================");
    }

    // =========================
    // GETTERS
    // =========================

    public String getName() {
        return name;
    }

    public String getProducer() {
        return producer;
    }

    public int getYear() {
        return year;
    }

    public double getWeight() {
        return weight;
    }

    public String getCaliber() {
        return caliber;
    }

    public int getCapacity() {
        return capacity;
    }

    public int getAmmoOnMag() {
        return ammoOnMag;
    }

    public GunType getType() {
        return type;
    }

    public FireMode getFireMode() {
        return fireMode;
    }

    public double getEffectiveRange() {
        return effectiveRange;
    }

    public int getFireRate() {
        return fireRate;
    }

    public int getTotalShots() {
        return totalShots;
    }

    public boolean isSafetyOn() {
        return safetyOn;
    }

    public double getCondition() {
        return condition;
    }

    public int getMagazineCount() {
        return magazineCount;
    }
}