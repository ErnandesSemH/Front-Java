
package com.example.gunlibrary.guns;

import java.time.Year;


public abstract class Gun {

    // =========================
    // ATTRIBUTES
    // =========================

    private String name;
    private String producer;
    private int year;
    private double weight;
    private String caliber;

    private GunType type;
    private FireMode fireMode;

    private double effectiveRange;
    private int fireRate;

    private int totalShots;
    private boolean safetyOn;
    private double condition;

    private final int capacity;
    private int ammoOnMag;
    private int magazineCount;

    // =========================
    // CONSTRUCTORS
    // =========================

    public Gun(
            String name,
            String producer,
            int year,
            double weight,
            String caliber,
            int capacity,
            GunType type,
            FireMode fireMode,
            double effectiveRange,
            int fireRate,
            int magazineCount
    ) {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Invalid gun name.");
        }

        if (producer == null || producer.isBlank()) {
            throw new IllegalArgumentException("Invalid producer.");
        }

        if (year < 1800 || year > Year.now().getValue()) {
            throw new IllegalArgumentException("Invalid manufacturing year.");
        }

        if (!Double.isFinite(weight) || weight <= 0) {
            throw new IllegalArgumentException("Invalid weight.");
        }

        if (caliber == null || caliber.isBlank()) {
            throw new IllegalArgumentException("Invalid caliber.");
        }

        if (capacity <= 0) {
            throw new IllegalArgumentException("Capacity must be positive.");
        }

        if (type == null || fireMode == null) {
            throw new IllegalArgumentException("Invalid gun type or fire mode.");
        }

        if (!Double.isFinite(effectiveRange) || effectiveRange < 0) {
            throw new IllegalArgumentException("Invalid effective range.");
        }

        if (fireRate < 0 || magazineCount < 0) {
            throw new IllegalArgumentException("Invalid fire rate or magazine count.");
        }

        this.name = name;
        this.producer = producer;
        this.year = year;
        this.weight = weight;
        this.caliber = caliber;
        this.capacity = capacity;
        this.ammoOnMag = capacity;

        this.type = type;
        this.fireMode = fireMode;
        this.effectiveRange = effectiveRange;
        this.fireRate = fireRate;

        this.totalShots = 0;
        this.safetyOn = true;
        this.condition = 100.0;
        this.magazineCount = magazineCount;
    }

    // =========================
    // POLYMORPHIC BEHAVIOUR
    // Cada arma concreta sobrescreve (@Override) estes métodos.
    // =========================

    /** Descreve como é o gatilho desta arma. */
    public abstract String getTriggerType();

    /** Onomatopeia / descrição do som do disparo. */
    public abstract String getSound();

    /** Descreve o mecanismo de funcionamento (ciclo de ação). */
    public abstract String getMechanism();

    /** Informação extra opcional (ex.: aumento da luneta). */
    public String getExtraInfo() {
        return null;
    }

    /** Armas de carregador removível usam carregadores reservas. */
    public boolean usesMagazine() {
        return true;
    }

    // =========================
    // SHOOT
    // =========================

    public ActionResult shoot() {
        if (safetyOn) {
            return ActionResult.fail(name + ": a trava está LIGADA. Desligue-a para atirar.");
        }

        if (ammoOnMag <= 0) {
            return ActionResult.fail(name + ": sem munição! Recarregue.");
        }

        ammoOnMag--;
        totalShots++;
        condition = Math.max(0, condition - 0.1);

        return ActionResult.ok(name + " disparou: " + getSound());
    }

    // =========================
    // RELOAD
    // =========================

    /**
     * Recarga padrão: troca de carregador. Subclasses com outro
     * sistema de alimentação (tambor, tubo) sobrescrevem este método.
     */
    public ActionResult reload() {
        if (ammoOnMag == capacity) {
            return ActionResult.fail(name + ": o carregador já está cheio.");
        }

        if (magazineCount <= 0) {
            return ActionResult.fail(name + ": sem carregadores reservas!");
        }

        int added = capacity - ammoOnMag;
        ammoOnMag = capacity;
        magazineCount--;

        return ActionResult.ok(
            name + " recarregada (+" + added + "): " + ammoOnMag + "/" + capacity
            + ". Carregadores reservas: " + magazineCount
        );
    }

    /** Usado por subclasses que recarregam sem carregador removível. */
    protected ActionResult refillChambers(String how) {
        if (ammoOnMag == capacity) {
            return ActionResult.fail(name + ": já está totalmente carregada.");
        }

        int added = capacity - ammoOnMag;
        ammoOnMag = capacity;

        return ActionResult.ok(
            name + " recarregada (+" + added + ") " + how + ": " + ammoOnMag + "/" + capacity
        );
    }

    public boolean isEmpty() {
        return ammoOnMag == 0;
    }

    public double getAmmoPercentage() {
        return (ammoOnMag * 100.0) / capacity;
    }

    // =========================
    // SAFETY
    // =========================

    public ActionResult toggleSafety() {
        safetyOn = !safetyOn;

        return ActionResult.ok(
            name + ": trava " + (safetyOn ? "LIGADA" : "DESLIGADA")
        );
    }

    // =========================
    // CONDITION
    // =========================

    public void inspect() {
        System.out.println("\n===== GUN INSPECTION =====");
        System.out.println("Name: " + name);
        System.out.println("Condition: " + condition + "%");
        System.out.println("Safety: " + (safetyOn ? "ON" : "OFF"));
        System.out.println("Ammo: " + ammoOnMag + "/" + capacity);
        System.out.println("Spare magazines: " + magazineCount);
        System.out.println("Total shots: " + totalShots);
        System.out.println("==========================");
    }

    public ActionResult maintain() {
        if (condition >= 100.0) {
            return ActionResult.fail(name + ": já está em perfeito estado.");
        }

        condition = 100.0;
        return ActionResult.ok(name + ": manutenção concluída (condição 100%).");
    }

    // =========================
    // COMPARISON
    // =========================

    public void compareWeight(Gun other) {
        if (other == null) {
            throw new IllegalArgumentException("Cannot compare with null.");
        }

        if (this.weight > other.weight) {
            System.out.println(
                    this.name + " is heavier than " + other.name
            );
        } else if (this.weight < other.weight) {
            System.out.println(
                    this.name + " is lighter than " + other.name
            );
        } else {
            System.out.println("Both guns have the same weight.");
        }
    }

    // =========================
    // INFORMATION
    // =========================

    public void showData() {
        System.out.println("\n===== GUN DATA =====");
        System.out.println("Name: " + name);
        System.out.println("Producer: " + producer);
        System.out.println("Year: " + year);
        System.out.println("Weight: " + weight + " kg");
        System.out.println("Caliber: " + caliber);
        System.out.println("Type: " + type);
        System.out.println("Fire mode: " + fireMode);
        System.out.println("Trigger: " + getTriggerType());
        System.out.println("Sound: " + getSound());
        System.out.println("Mechanism: " + getMechanism());
        System.out.println("Effective range: " + effectiveRange + " m");
        System.out.println("Fire rate: " + fireRate + " RPM");
        System.out.println("Capacity: " + capacity);
        System.out.println("Current ammo: " + ammoOnMag);
        System.out.println("Spare magazines: " + magazineCount);
        System.out.println("Condition: " + condition + "%");
        System.out.println("Total shots: " + totalShots);
        System.out.println("====================");
    }

    // =========================
    // GETTERS
    // =========================

    public String getName() {
        return name;
    }

    public String getProducer() {
        return producer;
    }

    public int getYear() {
        return year;
    }

    public double getWeight() {
        return weight;
    }

    public String getCaliber() {
        return caliber;
    }

    public int getCapacity() {
        return capacity;
    }

    public int getAmmoOnMag() {
        return ammoOnMag;
    }

    public GunType getType() {
        return type;
    }

    public FireMode getFireMode() {
        return fireMode;
    }

    public double getEffectiveRange() {
        return effectiveRange;
    }

    public int getFireRate() {
        return fireRate;
    }

    public int getTotalShots() {
        return totalShots;
    }

    public boolean isSafetyOn() {
        return safetyOn;
    }

    public double getCondition() {
        return condition;
    }

    public int getMagazineCount() {
        return magazineCount;
    }
}