$ErrorActionPreference = 'Stop'
Set-Location (Split-Path -Parent $PSScriptRoot)
$mvn = Get-Command mvn.cmd -ErrorAction SilentlyContinue
if ($mvn) { & $mvn.Source @args; exit $LASTEXITCODE }
$version = '3.9.11'
$dir = Join-Path $PSScriptRoot "apache-maven-$version"
$exe = Join-Path $dir 'bin/mvn.cmd'
if (-not (Test-Path $exe)) {
    $zip = Join-Path $PSScriptRoot 'maven-download.zip'
    $url = "https://repo.maven.apache.org/maven2/org/apache/maven/apache-maven/$version/apache-maven-$version-bin.zip"
    Write-Host 'Maven nao encontrado. Baixando Maven automaticamente (necessita internet)...'
    try {
        Invoke-WebRequest -Uri $url -OutFile $zip
        Expand-Archive -Path $zip -DestinationPath $PSScriptRoot -Force
        Remove-Item $zip
    } catch { Write-Error "Falha ao baixar Maven. Verifique sua conexao: $_"; exit 1 }
}
& $exe @args
exit $LASTEXITCODE
