# GunLibrary — API REST Spring Boot

Projeto acadêmico Java POO com frontend HTML/JS de demonstração. Operações simuladas, sem dispositivos físicos.

## Windows — como iniciar

1. Instale o **JDK 21** (não apenas JRE). Confirme com `java -version`.
2. Extraia todo o ZIP e entre na pasta `GunLibrary` que contém `pom.xml`.
3. Dê dois cliques em **INICIAR_API.cmd**. O script utiliza Maven instalado ou baixa Maven 3.9.11 automaticamente. A primeira execução exige internet para baixar dependências Spring Boot.
4. Aguarde a mensagem `Started GunlibraryApplication` e acesse **http://localhost:8080/** no navegador.
5. API JSON: **http://localhost:8080/api/guns**.

Também é possível abrir CMD na raiz e executar `mvnw.cmd clean test` e `mvnw.cmd spring-boot:run`.

## Endpoints

- `GET /api/guns` — listar
- `GET /api/guns/{id}` — consultar (IDs 1 a 5)
- `POST /api/guns/{id}/shoot` — simular disparo
- `POST /api/guns/{id}/reload` — recarregar
- `POST /api/guns/{id}/safety` — alternar trava
- `POST /api/guns/{id}/maintain` — manutenção

Exemplo no CMD: `curl http://localhost:8080/api/guns`

## Observações

- Estado armazenado em memória: reiniciar restaura os cinco objetos.
- O método `shoot()` original imprime mensagens no terminal; a API retorna o estado atualizado, mesmo quando a trava impede o disparo.
- Os dados de arma são apenas uma simulação acadêmica.
- Java 21 e internet são necessários na primeira execução. Não foi possível executar o Maven/Spring Boot neste ambiente sem acesso à rede; a compilação do domínio Java foi validada com `javac`.
