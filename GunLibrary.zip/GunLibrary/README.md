# GunLibrary — API REST Spring Boot

Projeto acadêmico Java POO com frontend HTML/JS de demonstração. Operações simuladas, sem dispositivos físicos.

## Windows — como iniciar

1. Instale o **JDK 21** (não apenas JRE). Confirme com `java -version`.
2. Extraia todo o ZIP e entre na pasta `GunLibrary` que contém `pom.xml`.
3. Dê dois cliques em **INICIAR_API.cmd**. O script utiliza Maven instalado ou baixa Maven 3.9.11 automaticamente. A primeira execução exige internet para baixar dependências Spring Boot.
4. Aguarde a mensagem `Started GunlibraryApplication` e acesse **http://localhost:8080/** no navegador: o site completo (Início, Armas, Locais de venda e Clubes) já é servido pelo próprio Spring Boot.
5. API JSON: **http://localhost:8080/api/guns**.
6. Página de demonstração simples do back-end: **http://localhost:8080/demo.html**.

## Onde ficam os arquivos do site (HTML)

Tudo o que o Spring Boot serve como site fica em `src/main/resources/static/`:

| Arquivo | Endereço |
|---|---|
| `index.html` | http://localhost:8080/ |
| `Pagina_de_armas.html` | http://localhost:8080/Pagina_de_armas.html (consome a API `/api/guns`) |
| `Pagina_de_venda.html` | http://localhost:8080/Pagina_de_venda.html |
| `Pagina_de_clubes.html` | http://localhost:8080/Pagina_de_clubes.html |
| `demo.html` | http://localhost:8080/demo.html (demonstração antiga do back) |

Depois de editar um HTML, basta salvar e recarregar o navegador (se o Spring estiver rodando pelo `mvnw`, reinicie caso a alteração não apareça).

Se preferir abrir os HTMLs pelo **Live Server** (VS Code), ele pode usar as portas 5500 (`localhost` ou `127.0.0.1`): a página de armas detecta que não está na porta 8080 e chama a API em `http://localhost:8080/api/guns` (CORS liberado em `config/CorsConfig.java`). Abrir o arquivo direto do disco (`file://`) não funciona com a API por causa do CORS.

Também é possível abrir CMD na raiz e executar `mvnw.cmd clean test` e `mvnw.cmd spring-boot:run`.

## Endpoints

- `GET /api/guns` — listar
- `GET /api/guns/{id}` — consultar (IDs 1 a 5)
- `POST /api/guns/{id}/shoot` — simular disparo
- `POST /api/guns/{id}/reload` — recarregar
- `POST /api/guns/{id}/safety` — alternar trava
- `POST /api/guns/{id}/maintain` — manutenção

Exemplo no CMD: `curl http://localhost:8080/api/guns`

## Observações

- Estado armazenado em memória: reiniciar restaura os cinco objetos.
- Os métodos de ação (`shoot`, `reload`, `toggleSafety`, `maintain`) retornam um `ActionResult` (sucesso + mensagem) em vez de imprimir no terminal. A API devolve `{ success, message, gun }`; quando a trava impede o disparo a resposta é HTTP 200 com `success: false`.
- Polimorfismo: cada modelo sobrescreve (`@Override`) `getTriggerType()`, `getSound()` e `getMechanism()`. `Revolver` e `Shotgun` sobrescrevem `reload()` e `usesMagazine()`; `PrecisionRifle` sobrescreve `getExtraInfo()`.
- CORS liberado para o Live Server (`http://localhost:5500` e `http://127.0.0.1:5500`) e para `http://localhost:5173` — veja `config/CorsConfig.java`.
- Os dados de arma são apenas uma simulação acadêmica.
- Java 21 e internet são necessários na primeira execução. Não foi possível executar o Maven/Spring Boot neste ambiente sem acesso à rede; a compilação do domínio Java foi validada com `javac`.
